<?php
$pageName = "featured";
include "header.php";
?>

      <div class="body-elements">
         <div id="posters-responsive" >
            <div class="posters-holder">
            </div>
         </div>
      </div>
      <!--body elements-->
<script>loadFeatured();</script>

<?php
include "footer.php";
?>