<?php
$pageName = "welcome";
include "header.php";
?>

 <h2 class='homepage-hits'>  Checkout what's trending </h2>
      <div class="hero-posters">
      </div>

<script>loadSplashPosters();</script>

<?php
include "footer.php";
?>