<?php
//to be replaced in practical 4
$loggedIn = false;
$userName = "Giovanni";

$servername = "wheatley.cs.up.ac.za";
$username = "u18009035";
$password = "G10v@nn1";
$dbname = "u18009035_COS216";

?>