<?php

 echo   "<footer>
         <p>COS216 Practical 1 - u18009035</p>
      </footer>
   </body>
</html>";


?>